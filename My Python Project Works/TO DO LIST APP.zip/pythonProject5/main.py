import tkinter as tk
from tkinter import messagebox as mg
list_content=[]
 # Area to create functions for buttons
 # defining the function to add task to the list
def add_task():
    content=entry.get()
    list_content.append(content)
    entry.delete(0,"end")
    update_list()



# defining the function to to  update the list
def update_list():
    listbox.delete(0,"end")
    for x in list_content:
        listbox.insert(tk.END,x)

# defining the function to delete   single task
def delete_task():
    content_delete=listbox.get(tk.ACTIVE)
    if content_delete in list_content:
        list_content.remove(content_delete)
        update_list()



# defining the function to delete all task from the list
def delete_all_tasks():
    global list_content
    list_content=[]
    update_list()

 # defining the function to exit
def exit_p():
    answer=mg.askquestion("Quit","Do you want to quit")
    if answer=="yes":
        root.destroy()
    else:
        pass


def submit_func():
    ok=check_error()
    if ok==1:
        add_task()

# function to check entry if there is an input
def check_error():
    check=entry.get()
    if check=="":
        mg.showinfo("Input error","Please input your task")

    return 1



# creating root window
root=tk.Tk()
root.title("TO-DO APP LIST")
root.geometry("700x300+300+100")
root.resizable(False,False)
root["bg"]="black"


# creating widgets
header=tk.Label(text="Enter Your Task",font="arial 15 bold",)
header.place(x=250,y=30)

entry=tk.Entry(width=50,relief=tk.RAISED)
entry.place(x=180,y=70)


#submit button
submit=tk.Button(text="Submit",width=10,fg="red",command=submit_func)
submit.place(x=100,y=100)

frame=tk.Frame(root,height=100,width=300,background="blue")
frame.place(x=150,y=150)


sbb=tk.Scrollbar(frame,orient="vertical")
sbb.pack(side="right",fill="y")


#delete buttonhei
del_button=tk.Button(text="Delete a Task ",width=10,fg="red",command=delete_task)
del_button.place(x=230,y=100)

#textbox
listbox=tk.Listbox(frame,height=6,width=47,yscrollcommand=sbb.set)
listbox.pack()
sbb.config(command=listbox.yview)

del_all_button=tk.Button(text="Delete all Task",width=10,fg="red",command=delete_all_tasks)
del_all_button.place(x=360,y=100)

#  exit button
exit_button=tk.Button(text="Exit",width=10,fg="red",command=exit_p)
exit_button.place(x=480,y=100)






root.mainloop()



