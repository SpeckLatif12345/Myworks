import tkinter as tk
from tkinter.filedialog import askopenfilename, asksaveasfilename
win=tk.Tk()
win.title("Text  Editor Application")

# configure window using grid
win.columnconfigure(1,minsize=400,weight=1)
win.rowconfigure(0,minsize=400,weight=1)




# assigning functions to open button and save buttons
def open_file():
    """ to open file for editing  """
    filepath=askopenfilename(
        title="Select a file",initialdir="/",
        filetypes=[   ("text files","*.txt"),  ("All files","*.*")  ]
         )
    if not filepath:
        return
    txt_box.delete(1.0,tk.END)
    with  open(filepath,"r") as input_file:
        text=input_file.read()
        txt_box.insert(tk.END,text)
        win.title(f"Text Editor Application {filepath}")



#  To Save Command
def save_as():
    filepath=asksaveasfilename(
        title="Save as",
        defaultextension="txt",
        filetypes=[  ("text tiles", "*.txt"),  ("All  files","*.*") ]
    )

    if not  filepath:
        return

    with open(filepath,"w")  as output_file:
        text=txt_box.get(1.0,tk.END)
        output_file.write(text)
        win.title(f" Text Editor Application {filepath}")



# creating textbox
txt_box =tk.Text(win)
txt_box.grid(row=0,column=1,sticky="nsew")

#  creating of frame to place textbox and buttons
frame_button=tk.Frame(win,relief=tk.RAISED,bd=2)
frame_button.grid(row=0,column=0,sticky="ns")

# Open Button
open_button=tk.Button(frame_button,text="open",command=open_file)
open_button.grid(row=0,column=0,sticky="ew",padx=5,pady=5)

# Save Button
save_button=tk.Button(frame_button,text="Save",command=save_as)
save_button.grid(row=1,column=0,sticky="ew",padx=5,pady=5)







win.mainloop()