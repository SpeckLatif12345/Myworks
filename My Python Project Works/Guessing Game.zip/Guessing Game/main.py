# import tkinter
# import PIL
#  import random
import random
import tkinter as tk
from PIL import Image, ImageTk
from  tkinter import messagebox

pc_score=0
user_score=0

# other functions
def enter(event):
    rock.config(bg="red",fg="black")
def enter1(event):
    paper.config(bg="red",fg="black")
def enter2(event):
    scissor.config(bg="red",fg="black")
def leave(event):
    rock.config(bg="grey",fg="black")
def leave1(event):
    paper.config(bg="grey",fg="black")
def leave2(event):
    scissor.config(bg="grey",fg="black")


# function to check if name was entered
def name_check():
    name=user_name.get()
    if len(name)< 5:
        messagebox.showinfo(("Name should not be less than 5 characters"))
    else:
        main_game()



# Main_Game Entry:
def entergame(event): # entergame function  receives event
    name=user_name.get()
    if len(name)< 5:
        messagebox.showinfo("Name should not be less than 5 characters")
    else :
        main_game()

def main_game():  # does not receive any parameter
    #destroying widgets to create new window
    global pc_score
    global user_score
    global player_score
    global computer_score
    Label_name.destroy()
    name_entry.destroy()
    play_button.destroy()



    root.geometry("650x600")



    def click(event):
        global computer_choice
        global user_choice
        global pc_score
        global user_score
        global rock,paper,scissor
        global player_score,computer_score

        # destroy computer_choice label
        computer_choice.destroy()
        # destroy user_choice label
        user_choice.destroy()

        # destroying player_score and computer_score when game restarts
        player_score.destroy()
        computer_score.destroy()


        global won_label
        # destroy won_label  label
        won_label.destroy()

        value = event.widget.cget("text")

        # User Choice Label
        user_choice = tk.Label(root, text=f"{user_name.get()} selected  : {value}  ", font="comicsan 14 bold",bg="blue",fg="white")
        user_choice.place(x=70, y=370)

        item_list=["Rock","Paper","Scissor"]
        computer_choose= random.choice(item_list)


        # Computer Choice Label
        computer_choice = tk.Label(root, text=f"Computer Selected : {computer_choose}", font="comicsan 14 bold ",
                                   bg="blue", fg="white")
        computer_choice.place(x=370, y=370)


        # if conditions
        if value=="Rock" and computer_choose=="Paper" :
            won_label=tk.Label(root,text="Computer Won",font="lucida 15 bold",bg="black",fg="gold")
            pc_score = pc_score + 1
            won_label.place(x=250,y=480)


            #  else if condition
        elif value=="Rock"  and  computer_choose=="Scissor":
            won_label=tk.Label(root,text=f"{user_name.get()} Won ",font="lucida 15 bold",bg="black",fg="gold")
            user_score = user_score + 1
            won_label.place(x=250,y=480)


        elif value=="Paper"  and  computer_choose=="Scissor":
            won_label=tk.Label(root, text="Computer Won", font="lucida 15 bold",bg="black",fg="gold")
            pc_score = pc_score + 1
            won_label.place(x=250,y=480)





        elif value=="Paper"  and computer_choose=="Rock":
            won_label=tk.Label(root,text=f"{user_name.get()} Won ",font="lucida 15 bold",bg="black",fg="gold" )
            user_score = user_score + 1
            won_label.place(x=250,y=480)


        elif value=="Scissor"  and  computer_choose=="Rock":
            won_label=tk.Label(root,text=f"{user_name.get()} Won ",font="lucida 15 bold",bg="black",fg="gold" )
            user_score = user_score + 1
            won_label.place(x=250,y=480)


        elif value==computer_choose:
            won_label=tk.Label(root, text="it is a  Tie ", font="lucida 15 bold",bg="black",fg="gold")
            won_label.place(x=250,y=480)

            # widgets to display scores
            player_score = tk.Label(root, text=f"{user_name.get()} Score  :   {user_score}", font="arial 14 bold",
                                    bg="white",
                                    height=1, fg="red", relief=tk.RAISED)
            player_score.place(x=90, y=420)

            computer_score = tk.Label(root, text=f"Computer Score  : {pc_score} ", font="arial 14 bold", bg="white",
                                      height=1,
                                      fg="red", relief=tk.RAISED)
            computer_score.place(x=370, y=420)



















    # Label to display welcome WELCOME TO ROCK PAPER SCISSOR GAME
    wel_label=tk.Label(root,text="ROCK PAPER SCISSOR GAME",bg="black",fg="white",font="arial 30 bold")
    wel_label.place(x=30,y=50)

    # Label to display players

    player_1=tk.Label(text=f"Player One : {user_name.get()}", fg="black",font="lucida 20 bold")# player 1
    player_1.place(x=30,y=150)

    player_2=tk.Label(text="Player Two : Computer", fg="black", font="lucida 20 bold") # player 2 Computer
    player_2.place(x=320,y=150)

    #  Creation of Buttons for Player 1 :
    # creation of frame to put them inside
    frame=tk.Frame(root,bg="white")
    frame.place(x=100,y=200)

    rock=tk.Button(frame,text="Rock",font="comicsan 14 bold",bg="grey",height=1,width=7)
    rock.grid(row=0,column=0,padx=5,pady=5)
    rock.bind("<Button-1>",click)
    rock.bind("<Enter>",enter)
    rock.bind("<Leave>",leave)



    paper=tk.Button(frame,text="Paper",font="comicsan 14 bold",bg="grey",height=1,width=7)
    paper.grid(row=1,column=0,padx=5,pady=5)
    paper.bind("<Button-1>",click)
    paper.bind("<Enter>",enter1)
    paper.bind("<Leave>",leave1)

    scissor=tk.Button(frame,text="Scissor",font="comicsan 14 bold",bg="grey",height=1,width=7)
    scissor.grid(row=2,column=0,padx=5,pady=5)
    scissor.bind("<Button-1>",click)
    scissor.bind("<Enter>",enter2)
    scissor.bind("<Leave>",leave2)

    # Creation of Buttons for Player 2 ( Computer):
    frame1=tk.Frame(root,bg="white")
    frame1.place(x=420,y=200)

    rock1=tk.Button(frame1,text="Rock",font="comiscsan 14 bold",bg="grey",height=1,width=7)
    rock1.grid(row=0,column=0,padx=5,pady=5)

    paper1=tk.Button(frame1,text="Paper",font="comicsan 14 bold",bg="grey",height=1,width=7)
    paper1.grid(row=1,column=0,pady=5,padx=5)

    scissor1=tk.Button(frame1,text="Scissor",font="comicsan 14 bold",bg="grey",height=1,width=7)
    scissor1.grid(row=2,column=0,padx=5,pady=5)
























    # close game button
    close_game=tk.Button(root,text="Close Game",bg="green",fg="black",font="comicsan 14 bold",command=root.destroy)
    close_game.place(x=250,y=550)
































#  root window
root=tk.Tk()
root.title("Rock Paper Game") # root title
root.iconphoto(False,tk.PhotoImage(file="./play.png")) # changing window icon photo
bg=tk.PhotoImage(file="./play2.png") # taking path to photo

root.geometry("650x600") # window dimension
root.maxsize(650,600) # max size
root.resizable(False,False) # resizing is False
root["bg"]="green" # applying background color

# creating canvas to place photo on it
canvas1=tk.Canvas(root,width=650,height=600)
canvas1.pack()
canvas1.create_image(0,0,image=bg)


# creating a frame to put name and entry widgets on it
#  widget to  display information to enter Name
Label_name=tk.Label(root, text="Enter Your Name :", font="Calibri 30 bold",anchor=tk.CENTER)
Label_name.place(x=175,y=250)

# widget to enter your Name
user_name=tk.StringVar()
name_entry=tk.Entry(root, textvariable=user_name,width=43,bd=2,cursor="arrow",font="arial 10 bold")
name_entry.bind("<Return>", entergame )
name_entry.place(x=175,y=300)


play_button=tk.Button(root,text="Let's Play", font="arial 10 bold", bg="black",fg="white",command=name_check)
play_button.place(x=280,y=340)

computer_choice=tk.Label()
user_choice=tk.Label()
won_label=tk.Label()

rock=tk.Label()
paper=tk.Label()
scissor=tk.Label()
player_score=tk.Label()
computer_score=tk.Label()

















root.mainloop()
